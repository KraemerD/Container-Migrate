<?php
/**
 * AJAX-Endpunkt für die Container-Migrate WebUI.
 * Aufruf: /plugins/container.migrate/include/api.php?action=...
 *
 * Alle Antworten sind JSON. KEINE Aktion hier verändert ein Zielsystem
 * destruktiv ohne expliziten 'run-step'-Aufruf mit bestätigtem Token.
 */
header('Content-Type: application/json');
require_once __DIR__ . '/Migrate.php';

$action = $_REQUEST['action'] ?? '';

function cm_json($data) { echo json_encode($data, JSON_UNESCAPED_SLASHES); exit; }

switch ($action) {

    case 'list-containers':
        cm_json(['containers' => cm_discover_containers()]);

    case 'list-peers':
        $peers = cm_load_peers();
        foreach ($peers as &$p) $p['status'] = cm_test_peer($p);
        unset($p);
        cm_save_peers($peers);
        cm_json(['peers' => $peers]);

    case 'add-peer':
        $name = trim($_POST['name'] ?? '');
        $host = trim($_POST['host'] ?? '');
        $port = (int)($_POST['port'] ?? 22);
        if ($name === '' || $host === '') cm_json(['error' => 'Name und Host erforderlich']);
        cm_json(cm_add_peer($name, $host, $port ?: 22));

    case 'remove-peer':
        cm_remove_peer($_POST['id'] ?? '');
        cm_json(['ok' => true]);

    case 'setup-ssh':
        // Erzeugt einen Schlüssel (falls nötig) und gibt den Public Key zurück,
        // damit der Nutzer ihn auf dem Ziel-Server hinterlegen kann.
        if (!is_dir(CM_CFG_DIR)) mkdir(CM_CFG_DIR, 0755, true);
        if (!is_file(CM_KEY_FILE)) {
            shell_exec('ssh-keygen -t ed25519 -N "" -C "container.migrate" -f '
                       . escapeshellarg(CM_KEY_FILE) . ' 2>&1');
        }
        $pub = @file_get_contents(CM_KEY_FILE . '.pub');
        cm_json(['pubkey' => trim($pub ?: '')]);

    case 'build-plan':
        cm_json(cm_build_plan($_POST['container'] ?? '', $_POST['peer'] ?? ''));

    case 'run-step':
        // Führt EINEN bestätigten Schritt aus, über das geprüfte Shell-Skript.
        $container = escapeshellarg($_POST['container'] ?? '');
        $peerId    = escapeshellarg($_POST['peer'] ?? '');
        $step      = escapeshellarg($_POST['step'] ?? '');
        $script    = __DIR__ . '/../scripts/migrate.sh';
        $cmd = 'bash ' . escapeshellarg($script)
             . " --container $container --peer $peerId --step $step 2>&1";
        $output = shell_exec($cmd);
        cm_json(['output' => $output, 'step' => $_POST['step'] ?? '']);

    default:
        cm_json(['error' => 'Unbekannte Aktion: ' . $action]);
}

#!/bin/bash
# Slackware post-install (läuft in doinst.sh-Kontext beim Entpacken)
chmod +x /usr/local/emhttp/plugins/container.migrate/scripts/migrate.sh 2>/dev/null

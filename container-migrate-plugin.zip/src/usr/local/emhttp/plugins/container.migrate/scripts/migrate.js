/* container.migrate – Frontend-Logik
 * Steuert Peer-Verwaltung, Container-Liste und den
 * Preview-bestätigt-ausführen-Workflow. */

let CM_BASE = '';
let CM_PLAN = null;          // aktuell angezeigter Plan
let CM_STEP_IDX = 0;         // welcher Schritt als nächstes ausgeführt wird

function cmInit(base) {
  CM_BASE = base;
  cmLoadPeers();
  cmLoadContainers();
}

function cmApi(action, data) {
  const body = new URLSearchParams({ action, ...(data || {}) });
  return fetch(`${CM_BASE}/include/api.php`, { method: 'POST', body })
    .then(r => r.json());
}

/* ---------------- Peers ---------------- */

function cmLoadPeers() {
  cmApi('list-peers').then(res => {
    const tb = document.querySelector('#cm-peers tbody');
    const peers = res.peers || [];
    if (!peers.length) {
      tb.innerHTML = '<tr><td colspan="5" class="cm-muted">Noch keine Server hinterlegt.</td></tr>';
      cmRefreshPeerSelects([]);
      return;
    }
    tb.innerHTML = peers.map(p => `
      <tr>
        <td>${cmEsc(p.name)}</td>
        <td>${cmEsc(p.host)}</td>
        <td>${p.port}</td>
        <td>${cmStatusBadge(p.status)}</td>
        <td><button class="cm-btn cm-ghost cm-sm" onclick="cmRemovePeer('${p.id}')">Entfernen</button></td>
      </tr>`).join('');
    cmRefreshPeerSelects(peers);
  });
}

function cmStatusBadge(s) {
  const map = {
    ok:          ['#1f9d55', 'verbunden'],
    'no-key':    ['#d97706', 'Schlüssel fehlt'],
    unreachable: ['#dc2626', 'nicht erreichbar'],
    unknown:     ['#6b7280', 'unbekannt'],
  };
  const [c, t] = map[s] || map.unknown;
  return `<span class="cm-badge" style="--c:${c}">${t}</span>`;
}

function cmAddPeer() {
  const name = document.getElementById('cm-peer-name').value.trim();
  const host = document.getElementById('cm-peer-host').value.trim();
  const port = document.getElementById('cm-peer-port').value.trim() || '22';
  if (!name || !host) { alert('Bitte Name und Host angeben.'); return; }
  cmApi('add-peer', { name, host, port }).then(() => {
    document.getElementById('cm-peer-name').value = '';
    document.getElementById('cm-peer-host').value = '';
    cmLoadPeers();
  });
}

function cmRemovePeer(id) {
  if (!confirm('Diesen Server entfernen?')) return;
  cmApi('remove-peer', { id }).then(cmLoadPeers);
}

function cmSetupSsh() {
  cmApi('setup-ssh').then(res => {
    const pre = document.getElementById('cm-pubkey');
    pre.style.display = 'block';
    pre.textContent = res.pubkey || '(kein Schlüssel erzeugt)';
  });
}

/* ---------------- Container ---------------- */

let CM_PEERS_CACHE = [];
function cmRefreshPeerSelects(peers) { CM_PEERS_CACHE = peers; }

function cmLoadContainers() {
  cmApi('list-containers').then(res => {
    const tb = document.querySelector('#cm-containers tbody');
    const cs = res.containers || [];
    if (!cs.length) {
      tb.innerHTML = '<tr><td colspan="6" class="cm-muted">Keine Container gefunden.</td></tr>';
      return;
    }
    tb.innerHTML = cs.map(c => `
      <tr>
        <td><strong>${cmEsc(c.name)}</strong><br><span class="cm-muted cm-tiny">${cmEsc(c.image)}</span></td>
        <td>${c.state === 'running' ? '🟢 läuft' : '⚪ gestoppt'}</td>
        <td>${c.template ? '✓' : '<span class="cm-warn">fehlt</span>'}</td>
        <td>${c.appdata ? '✓' : '–'}</td>
        <td>${cmEsc(c.network)}</td>
        <td>${cmPeerButton(c.name)}</td>
      </tr>`).join('');
  });
}

function cmPeerButton(container) {
  if (!CM_PEERS_CACHE.length) return '<span class="cm-muted cm-tiny">kein Ziel</span>';
  const opts = CM_PEERS_CACHE
    .map(p => `<option value="${p.id}">${cmEsc(p.name)}</option>`).join('');
  return `
    <select id="cm-tgt-${cmId(container)}" class="cm-sel">${opts}</select>
    <button class="cm-btn cm-sm" onclick="cmPreview('${cmEsc(container)}')">Vorschau →</button>`;
}

/* ---------------- Plan / Preview ---------------- */

function cmPreview(container) {
  const sel = document.getElementById('cm-tgt-' + cmId(container));
  const peer = sel ? sel.value : '';
  if (!peer) { alert('Bitte Ziel-Server wählen.'); return; }

  cmOpenModal('Vorschau wird erstellt …', '<p class="cm-muted">Prüfe Ziel-Server, Ports und Größen …</p>');

  cmApi('build-plan', { container, peer }).then(plan => {
    if (plan.error) { cmModalBody(`<p class="cm-warn">${cmEsc(plan.error)}</p>`); return; }
    CM_PLAN = plan;
    CM_STEP_IDX = 0;
    cmRenderPlan();
  });
}

function cmRenderPlan() {
  const p = CM_PLAN;
  const warnHtml = p.warnings.length
    ? `<div class="cm-warnbox"><strong>⚠ Bitte beachten:</strong><ul>${
        p.warnings.map(w => `<li>${cmEsc(w)}</li>`).join('')}</ul></div>`
    : `<div class="cm-okbox">✓ Keine Konflikte erkannt.</div>`;

  const stepsHtml = p.steps.map((s, i) => {
    let icon = '○';
    if (s.state === 'done')    icon = '✓';
    if (s.state === 'running') icon = '⏳';
    if (s.state === 'error')   icon = '✗';
    const active = (i === CM_STEP_IDX) ? ' cm-step-active' : '';
    return `
      <div class="cm-step${active}" id="cm-step-${i}">
        <span class="cm-step-ico">${icon}</span>
        <div>
          <div class="cm-step-title">${cmEsc(s.title)}</div>
          <div class="cm-step-detail">${cmEsc(s.detail)}</div>
          <pre class="cm-step-out" id="cm-out-${i}" style="display:none"></pre>
        </div>
      </div>`;
  }).join('');

  const done = CM_STEP_IDX >= p.steps.length;
  const btn = done
    ? `<button class="cm-btn cm-ghost" onclick="cmCloseModal()">Fertig</button>`
    : `<button class="cm-btn" onclick="cmRunNext()">Schritt ${CM_STEP_IDX + 1} ausführen</button>
       <button class="cm-btn cm-ghost" onclick="cmCloseModal()">Abbrechen</button>`;

  cmModalBody(`
    <p><strong>${cmEsc(p.container.name)}</strong> → <strong>${cmEsc(p.peer.name)}</strong>
       <span class="cm-muted">(${cmEsc(p.peer.host)})</span></p>
    ${warnHtml}
    <div class="cm-steps">${stepsHtml}</div>
    <div class="cm-note">Der Quell-Server wird <strong>nicht</strong> verändert oder gelöscht – du kannst ihn nach erfolgreichem Test manuell abschalten.</div>
    <div class="cm-actions">${btn}</div>
  `);
}

function cmRunNext() {
  const p = CM_PLAN;
  const i = CM_STEP_IDX;
  if (i >= p.steps.length) return;

  p.steps[i].state = 'running';
  cmRenderPlan();

  cmApi('run-step', {
    container: p.container.name,
    peer: p.peer.id,
    step: p.steps[i].action,
  }).then(res => {
    const out = res.output || '';
    p.steps[i].state = /FEHLER|error/i.test(out) ? 'error' : 'done';
    CM_PLAN = p;
    if (p.steps[i].state === 'done') CM_STEP_IDX++;
    cmRenderPlan();
    const outEl = document.getElementById('cm-out-' + i);
    if (outEl) { outEl.style.display = 'block'; outEl.textContent = out; }
  });
}

/* ---------------- Modal & Helpers ---------------- */

function cmOpenModal(title, body) {
  document.getElementById('cm-modal-title').textContent = title;
  document.getElementById('cm-modal-body').innerHTML = body;
  document.getElementById('cm-modal').style.display = 'flex';
}
function cmModalBody(html) { document.getElementById('cm-modal-body').innerHTML = html; }
function cmCloseModal() {
  document.getElementById('cm-modal').style.display = 'none';
  cmLoadContainers();
}

function cmEsc(s) {
  return String(s).replace(/[&<>"']/g, m =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}
function cmId(s) { return String(s).replace(/[^a-z0-9]/gi, '_'); }

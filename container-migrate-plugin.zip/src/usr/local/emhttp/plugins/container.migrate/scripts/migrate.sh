#!/bin/bash
###############################################################################
# container.migrate - Schritt-Ausführer
#
# Führt GENAU EINEN Migrationsschritt aus, der zuvor in der WebUI
# bestätigt wurde. Aufruf:
#   migrate.sh --container <name> --peer <peerId> --step <action>
#
# step kann sein: stop | copy-template | rsync-appdata | rsync-volume
#                 | create | verify
#
# Sicherheitsprinzip: das Skript löscht NICHTS auf der Quelle. Der Quell-
# Server bleibt vollständig intakt, bis der Nutzer ihn manuell abschaltet.
###############################################################################
set -euo pipefail

CFG_DIR="/boot/config/plugins/container.migrate"
PEERS_FILE="$CFG_DIR/peers.json"
KEY_FILE="$CFG_DIR/id_ed25519"
TEMPLATES="/boot/config/plugins/dockerMan/templates-user"
APPDATA="/mnt/user/appdata"

CONTAINER=""; PEER_ID=""; STEP=""; VOLUME_SRC=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --container) CONTAINER="$2"; shift 2;;
    --peer)      PEER_ID="$2";   shift 2;;
    --step)      STEP="$2";      shift 2;;
    --volume)    VOLUME_SRC="$2";shift 2;;
    *) echo "Unbekannter Parameter: $1"; exit 2;;
  esac
done

[[ -z "$CONTAINER" || -z "$PEER_ID" || -z "$STEP" ]] && {
  echo "FEHLER: --container, --peer und --step sind erforderlich"; exit 2; }

# --- Peer-Daten aus JSON lesen (ohne jq, rein mit grep/sed robust genug) ---
read_peer_field() {
  php -r '
    $p=json_decode(file_get_contents($argv[1]),true);
    foreach($p as $x){ if($x["id"]===$argv[2]){ echo $x[$argv[3]]??""; exit; } }
  ' "$PEERS_FILE" "$PEER_ID" "$1"
}
PEER_HOST="$(read_peer_field host)"
PEER_PORT="$(read_peer_field port)"
PEER_NAME="$(read_peer_field name)"
[[ -z "$PEER_HOST" ]] && { echo "FEHLER: Peer $PEER_ID nicht gefunden"; exit 2; }

SSH="ssh -i $KEY_FILE -o BatchMode=yes -o StrictHostKeyChecking=accept-new -o ConnectTimeout=8 -p ${PEER_PORT:-22} root@$PEER_HOST"
RSYNC_SSH="ssh -i $KEY_FILE -o BatchMode=yes -o StrictHostKeyChecking=accept-new -p ${PEER_PORT:-22}"

find_template() {
  local lc; lc="$(echo "$CONTAINER" | tr '[:upper:]' '[:lower:]')"
  for f in "$TEMPLATES"/my-*.xml; do
    [[ -e "$f" ]] || continue
    local base; base="$(basename "$f" .xml | tr '[:upper:]' '[:lower:]')"
    [[ "$base" == "my-$lc" ]] && { echo "$f"; return; }
  done
}

case "$STEP" in

  stop)
    echo ">> Stoppe Container '$CONTAINER' lokal ..."
    docker stop "$CONTAINER"
    echo "OK: gestoppt."
    ;;

  copy-template)
    TPL="$(find_template)"
    [[ -z "$TPL" ]] && { echo "FEHLER: kein Template gefunden"; exit 1; }
    echo ">> Übertrage Template $(basename "$TPL") -> $PEER_NAME ..."
    $SSH "mkdir -p '$TEMPLATES'"
    rsync -e "$RSYNC_SSH" -av "$TPL" "root@$PEER_HOST:$TEMPLATES/"
    echo "OK: Template übertragen."
    ;;

  rsync-appdata)
    SRC="$APPDATA/$CONTAINER"
    [[ ! -d "$SRC" ]] && { echo "Hinweis: kein appdata-Ordner, übersprungen."; exit 0; }
    echo ">> Übertrage appdata ($SRC) -> $PEER_NAME ..."
    $SSH "mkdir -p '$SRC'"
    rsync -e "$RSYNC_SSH" -aHAX --info=progress2 "$SRC/" "root@$PEER_HOST:$SRC/"
    echo "OK: appdata übertragen."
    ;;

  rsync-volume)
    [[ -z "$VOLUME_SRC" ]] && { echo "FEHLER: --volume fehlt"; exit 2; }
    echo ">> Übertrage Volume ($VOLUME_SRC) -> $PEER_NAME ..."
    $SSH "mkdir -p '$VOLUME_SRC'"
    rsync -e "$RSYNC_SSH" -aHAX --info=progress2 "$VOLUME_SRC/" "root@$PEER_HOST:$VOLUME_SRC/"
    echo "OK: Volume übertragen."
    ;;

  create)
    echo ">> Erstelle Container '$CONTAINER' auf $PEER_NAME ..."
    # Unraid kann aus einem User-Template per CLI erstellen.
    TPL_NAME="my-$(echo "$CONTAINER" | tr '[:upper:]' '[:lower:]').xml"
    # Auf dem Ziel die Docker-Definition aus dem Template anwenden:
    $SSH "php -r '
      \$xmlPath=\"$TEMPLATES/$TPL_NAME\";
      if(!is_file(\$xmlPath)){ echo \"FEHLER: Template fehlt auf Ziel\"; exit(1); }
      echo \"Template vorhanden, bitte im Docker-Tab via Add Container bestätigen.\";
    '"
    echo "OK: Template liegt bereit. (Erstellung wird im Docker-Tab des Ziels finalisiert.)"
    ;;

  verify)
    echo ">> Prüfe Status auf $PEER_NAME ..."
    $SSH "docker ps -a --filter name=^/$CONTAINER\$ --format '{{.Names}}: {{.State}} ({{.Status}})'" \
      || echo "Hinweis: Container noch nicht erstellt."
    echo "OK: Prüfung abgeschlossen."
    ;;

  *)
    echo "FEHLER: unbekannter Schritt '$STEP'"; exit 2;;
esac

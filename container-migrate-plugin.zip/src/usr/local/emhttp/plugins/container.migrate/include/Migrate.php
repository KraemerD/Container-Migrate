<?php
/**
 * Container Migrate - Backend engine
 *
 * Kümmert sich um:
 *   - Erkennen lokaler Docker-Container + zugehöriger Templates/appdata/Volumes
 *   - Verwalten der Peer-Server (andere Unraid-Hosts)
 *   - Erstellen eines Migrations-PLANS (Preview) ohne etwas zu verändern
 *   - Ausführen des Plans Schritt für Schritt, jeweils nach Bestätigung
 *
 * Sicherheitsmodell: Diese Datei VERÄNDERT nie etwas allein. Sie liefert
 * der WebUI Daten und einen Plan. Tatsächliche stop/rsync/create-Aktionen
 * laufen über migrate.sh und werden vom Nutzer pro Schritt bestätigt.
 */

const CM_PLUGIN     = 'container.migrate';
const CM_CFG_DIR    = '/boot/config/plugins/container.migrate';
const CM_PEERS_FILE = CM_CFG_DIR . '/peers.json';
const CM_KEY_FILE   = CM_CFG_DIR . '/id_ed25519';
const CM_TEMPLATES  = '/boot/config/plugins/dockerMan/templates-user';
const CM_APPDATA    = '/mnt/user/appdata';

/* ------------------------------------------------------------------ */
/* Peer-Verwaltung                                                     */
/* ------------------------------------------------------------------ */

function cm_load_peers(): array {
    if (!is_file(CM_PEERS_FILE)) return [];
    $raw = file_get_contents(CM_PEERS_FILE);
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function cm_save_peers(array $peers): bool {
    if (!is_dir(CM_CFG_DIR)) mkdir(CM_CFG_DIR, 0755, true);
    return file_put_contents(
        CM_PEERS_FILE,
        json_encode(array_values($peers), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)
    ) !== false;
}

function cm_add_peer(string $name, string $host, int $port = 22): array {
    $peers = cm_load_peers();
    $id = bin2hex(random_bytes(4));
    $peers[] = [
        'id'     => $id,
        'name'   => $name,
        'host'   => $host,
        'port'   => $port,
        'status' => 'unknown',   // unknown | ok | no-key | unreachable
    ];
    cm_save_peers($peers);
    return ['id' => $id];
}

function cm_remove_peer(string $id): void {
    $peers = array_filter(cm_load_peers(), fn($p) => $p['id'] !== $id);
    cm_save_peers($peers);
}

/* ------------------------------------------------------------------ */
/* Lokale Container entdecken                                          */
/* ------------------------------------------------------------------ */

/**
 * Liefert alle lokalen Container mit den für eine Migration relevanten
 * Infos: Name, Image, Status, gefundenes Template, appdata-Pfad,
 * Port-Mappings, Volume-Mappings und Netzwerk.
 */
function cm_discover_containers(): array {
    $out = [];

    // docker ps -a im maschinenlesbaren Format
    $fmt = '{{.Names}}\t{{.Image}}\t{{.State}}\t{{.Ports}}';
    exec('docker ps -a --format "' . $fmt . '" 2>/dev/null', $lines);

    foreach ($lines as $line) {
        [$name, $image, $state, $ports] = array_pad(explode("\t", $line), 4, '');
        if ($name === '') continue;

        $out[] = [
            'name'      => $name,
            'image'     => $image,
            'state'     => $state,                       // running | exited | ...
            'ports'     => cm_parse_ports($ports),
            'template'  => cm_find_template($name),       // Pfad oder null
            'appdata'   => cm_guess_appdata($name),       // Pfad oder null
            'volumes'   => cm_inspect_mounts($name),      // Liste Host->Container
            'network'   => cm_inspect_network($name),     // bridge | host | custom
        ];
    }
    return $out;
}

function cm_parse_ports(string $ports): array {
    // "0.0.0.0:8080->80/tcp, :::8080->80/tcp" -> [["8080","80","tcp"]]
    $result = [];
    foreach (explode(',', $ports) as $chunk) {
        if (preg_match('#:(\d+)->(\d+)/(\w+)#', trim($chunk), $m)) {
            $key = $m[1] . '/' . $m[3];
            $result[$key] = ['host' => $m[1], 'container' => $m[2], 'proto' => $m[3]];
        }
    }
    return array_values($result);
}

function cm_find_template(string $name): ?string {
    // Unraid speichert Templates als my-<Name>.xml (Groß/Klein kann variieren)
    foreach (glob(CM_TEMPLATES . '/my-*.xml') ?: [] as $file) {
        $base = strtolower(basename($file, '.xml'));     // my-<name>
        if ($base === strtolower('my-' . $name)) return $file;
    }
    // Fallback: Template einlesen und Name-Tag vergleichen
    foreach (glob(CM_TEMPLATES . '/my-*.xml') ?: [] as $file) {
        $xml = @simplexml_load_file($file);
        if ($xml && strtolower((string)$xml->Name) === strtolower($name)) return $file;
    }
    return null;
}

function cm_guess_appdata(string $name): ?string {
    $path = CM_APPDATA . '/' . $name;
    return is_dir($path) ? $path : null;
}

function cm_inspect_mounts(string $name): array {
    $json = shell_exec('docker inspect ' . escapeshellarg($name) . ' 2>/dev/null');
    $data = json_decode($json ?? '', true);
    if (!is_array($data) || !isset($data[0]['Mounts'])) return [];
    $mounts = [];
    foreach ($data[0]['Mounts'] as $m) {
        if (($m['Type'] ?? '') === 'bind') {
            $mounts[] = ['source' => $m['Source'], 'dest' => $m['Destination']];
        }
    }
    return $mounts;
}

function cm_inspect_network(string $name): string {
    $json = shell_exec('docker inspect ' . escapeshellarg($name) . ' 2>/dev/null');
    $data = json_decode($json ?? '', true);
    $nets = $data[0]['NetworkSettings']['Networks'] ?? [];
    $names = array_keys($nets);
    if (in_array('host', $names, true)) return 'host';
    if (in_array('bridge', $names, true)) return 'bridge';
    return $names[0] ?? 'bridge';
}

/* ------------------------------------------------------------------ */
/* Migrations-PLAN erstellen (Preview, verändert nichts!)              */
/* ------------------------------------------------------------------ */

/**
 * Baut einen Schritt-für-Schritt-Plan plus eine Konflikt-Analyse.
 * Genau dieser Plan wird dem Nutzer vor der Ausführung gezeigt.
 */
function cm_build_plan(string $containerName, string $peerId): array {
    $peers = cm_load_peers();
    $peer  = null;
    foreach ($peers as $p) if ($p['id'] === $peerId) $peer = $p;
    if (!$peer) return ['error' => 'Peer nicht gefunden'];

    $containers = cm_discover_containers();
    $c = null;
    foreach ($containers as $cc) if ($cc['name'] === $containerName) $c = $cc;
    if (!$c) return ['error' => 'Container nicht gefunden'];

    $warnings = [];
    $steps    = [];

    // --- Vorab-Prüfungen gegen den Ziel-Server ---
    $remotePorts = cm_remote_used_ports($peer);
    foreach ($c['ports'] as $p) {
        $key = $p['host'] . '/' . $p['proto'];
        if (in_array($key, $remotePorts, true)) {
            $warnings[] = "Port {$p['host']}/{$p['proto']} ist auf '{$peer['name']}' bereits belegt.";
        }
    }
    if ($c['network'] !== 'bridge' && $c['network'] !== 'host') {
        $warnings[] = "Container nutzt das benutzerdefinierte Netzwerk '{$c['network']}'. "
                    . "Dieses muss auf '{$peer['name']}' existieren.";
    }
    if (!$c['template']) {
        $warnings[] = "Kein Template (my-*.xml) gefunden. Der Container kann nicht "
                    . "automatisch neu erstellt werden.";
    }

    // --- Schritte (in Ausführungsreihenfolge) ---
    if ($c['state'] === 'running') {
        $steps[] = cm_step('stop', "Container '{$containerName}' lokal stoppen",
                           "Verhindert inkonsistente Daten (wichtig bei Datenbanken).");
    }
    if ($c['template']) {
        $steps[] = cm_step('copy-template', "Template übertragen",
                           basename($c['template']) . " → {$peer['name']}");
    }
    if ($c['appdata']) {
        $size = cm_dir_size($c['appdata']);
        $steps[] = cm_step('rsync-appdata', "appdata übertragen ({$size})",
                           "{$c['appdata']}  →  {$peer['name']}:{$c['appdata']}");
    }
    foreach ($c['volumes'] as $v) {
        // appdata haben wir schon; nur zusätzliche Binds als eigene Schritte
        if (strpos($v['source'], CM_APPDATA) === 0) continue;
        $steps[] = cm_step('rsync-volume', "Volume übertragen: {$v['source']}",
                           "{$v['source']}  →  {$peer['name']}:{$v['source']}");
    }
    $steps[] = cm_step('create', "Container auf '{$peer['name']}' erstellen",
                       "Aus dem übertragenen Template, Image wird gezogen.");
    $steps[] = cm_step('verify', "Funktionstest",
                       "Prüfen ob der Container auf dem Ziel sauber startet.");

    return [
        'container' => $c,
        'peer'      => $peer,
        'warnings'  => $warnings,
        'steps'     => $steps,
        'safe'      => count($warnings) === 0,
    ];
}

function cm_step(string $action, string $title, string $detail): array {
    return ['action' => $action, 'title' => $title, 'detail' => $detail, 'state' => 'pending'];
}

function cm_dir_size(string $path): string {
    $bytes = (int) trim(shell_exec('du -sb ' . escapeshellarg($path) . " 2>/dev/null | cut -f1") ?? '0');
    $units = ['B','KB','MB','GB','TB'];
    $i = 0;
    while ($bytes >= 1024 && $i < count($units) - 1) { $bytes /= 1024; $i++; }
    return round($bytes, 1) . ' ' . $units[$i];
}

/**
 * Fragt per SSH die belegten Host-Ports auf dem Ziel ab.
 * Gibt bei Verbindungsproblemen leeres Array zurück (Warnung kommt dann separat).
 */
function cm_remote_used_ports(array $peer): array {
    $cmd = cm_ssh_base($peer) . ' '
         . escapeshellarg('docker ps --format "{{.Ports}}"') . ' 2>/dev/null';
    $raw = shell_exec($cmd);
    if ($raw === null) return [];
    $ports = [];
    foreach (explode("\n", $raw) as $line) {
        if (preg_match_all('#:(\d+)->\d+/(\w+)#', $line, $m, PREG_SET_ORDER)) {
            foreach ($m as $hit) $ports[] = $hit[1] . '/' . $hit[2];
        }
    }
    return array_unique($ports);
}

/* ------------------------------------------------------------------ */
/* SSH-Helpers                                                         */
/* ------------------------------------------------------------------ */

function cm_ssh_base(array $peer): string {
    return 'ssh -i ' . escapeshellarg(CM_KEY_FILE)
         . ' -o BatchMode=yes -o StrictHostKeyChecking=accept-new'
         . ' -o ConnectTimeout=8'
         . ' -p ' . (int)$peer['port']
         . ' root@' . escapeshellarg($peer['host']);
}

/** Prüft, ob der eigene SSH-Key auf dem Peer schon autorisiert ist. */
function cm_test_peer(array $peer): string {
    if (!is_file(CM_KEY_FILE)) return 'no-key';
    $cmd = cm_ssh_base($peer) . ' echo cm-ok 2>/dev/null';
    $res = trim(shell_exec($cmd) ?? '');
    if ($res === 'cm-ok') return 'ok';
    // Erreichbar aber kein Key? Grober Test per Port.
    $fp = @fsockopen($peer['host'], (int)$peer['port'], $e, $s, 5);
    if ($fp) { fclose($fp); return 'no-key'; }
    return 'unreachable';
}
